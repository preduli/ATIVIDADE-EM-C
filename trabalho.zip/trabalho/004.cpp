#include <stdio.h>
#include <locale.h>
int main(){
setlocale(LC_ALL, "Portuguese");
int n1, i, primo = 1;
printf("informe um numero: ");
scanf("%d", &n1);

if (n1 < 2 ){
primo = 0; 	
} else {
for (i=2; i<= n1/2; i++){
   if (n1 % i == 0){
       primo = 0;
	   break;   
   }
 }
}
  if (primo){
  printf("%d � um n�mero primo! \n", n1);
} else{
printf("%d n�o � n�mero primo!\n", n1);
}


return 0;

}
